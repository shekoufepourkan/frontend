const SUBMIT   = $('#submit');

var email    = null;
var password = null;
var confirm  = null;


function updateInfo() {
    email    = $('#email').val();
    password = $('#password').val();
    confirm  = $('#confirm').val();
    console.log(!email || !password || !confirm || password !== confirm);
}

function checkDisablingButton() {
    if (!email || !password || !confirm || password !== confirm)
        SUBMIT.attr('disabled', 'disabled');
    else
        SUBMIT.removeAttr('disabled');
}

$('#signupForm').change(() => {
    updateInfo();
    checkDisablingButton();
});



function signUpUser() {
    updateInfo();
    
    AUTH.createUserWithEmailAndPassword(email, password)
        .then(response => {
            localStorage.setItem('TOKEN', JSON.stringify(response))
            location.assign('index.html');
            window.alert('Welcome!');
        })
        .catch(error => alert('FAILED: ' + error));
}

SUBMIT.click(signUpUser);
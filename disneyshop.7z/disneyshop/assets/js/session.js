const TOKEN = localStorage.getItem('TOKEN');

if (!!TOKEN) {
    $('#login').addClass('u-hidden');
    $('#signup').addClass('u-hidden');
    
    console.log(JSON.parse(TOKEN));
    const EMAIL = JSON.parse(TOKEN).user.email;
    $('#userEmailPlace').text(EMAIL);
}
else {
    $('#logout').addClass('u-hidden');
    $('#userEmail').addClass('u-hidden');
}

$('#logout').click(() =>
    AUTH.signOut()
        .then(() => {
            $('#login').removeClass('u-hidden');
            $('#signup').removeClass('u-hidden');
    
            $('#logout').addClass('u-hidden');
            $('#userEmail').addClass('u-hidden');

            localStorage.removeItem('TOKEN');
        })
);
DATABASE.collection('rainbow').get().then(snapshot => {
    let html = '';

    snapshot.docs.forEach(doc => {
        const DATA = doc.data();
        html += `
            <div class="col-md-3 col-sm-6">
                <div class="thumbnail no-border no-padding">
                    <div class="media">
                        <a class="media-link">
                            <img src="${DATA.image}" alt=""/ style="height: 262.5px;">
                        </a>
                    </div>
                    <div class="caption text-center">
                        <h4 class="caption-title"><a href="">${DATA.title}</a></h4>
                    </div>
                </div>
            </div>
        `;
    });

    $('#rainbow').html(html);
})



const PRODUCTS = DATABASE.collection('products').doc('cM1d3vwyRq4V4mSPBkQc');

PRODUCTS.collection('just10').get().then(snapshot => {
    let html = `
        <a class="btn btn-theme btn-title-more" href="#">See All</a>
        <h4 class="block-title"><span>JUST $10</span></h4>
    `;

    snapshot.docs.forEach(doc => {
        const DATA = doc.data();
        html += `
            <div class="media">
                <a class="pull-left media-link" href="#">
                    <img class="media-object" src="${DATA.image}" alt="">
                    <i class="fa fa-plus"></i>
                </a>

                <div class="media-body">
                    <div class="price"><ins>${DATA.price}</ins></div>
                </div>
            </div>
        `;
    });

    $('#just10Products').html(html);
});

PRODUCTS.collection('home').get().then(snapshot => {
    let html = `
        <a class="btn btn-theme btn-title-more" href="#">See All</a>
        <h4 class="block-title"><span>HOME</span></h4>
    `;

    snapshot.docs.forEach(doc => {
        const DATA = doc.data();
        html += `
            <div class="media">
                <a class="pull-left media-link" href="#">
                    <img class="media-object" src="${DATA.image}" alt="">
                    <i class="fa fa-plus"></i>
                </a>

                <div class="media-body">
                    <div class="price"><ins>${DATA.price}</ins></div>
                </div>
            </div>
        `;
    });

    $('#homeProducts').html(html);
});

PRODUCTS.collection('toys').get().then(snapshot => {
    let html = `
        <a class="btn btn-theme btn-title-more" href="#">See All</a>
        <h4 class="block-title"><span>TOYS</span></h4>
    `;

    snapshot.docs.forEach(doc => {
        const DATA = doc.data();
        html += `
            <div class="media">
                <a class="pull-left media-link" href="#">
                    <img class="media-object" src="${DATA.image}" alt="">
                    <i class="fa fa-plus"></i>
                </a>

                <div class="media-body">
                    <div class="price"><ins>${DATA.price}</ins></div>
                </div>
            </div>
        `;
    });

    $('#toysProducts').html(html);
});
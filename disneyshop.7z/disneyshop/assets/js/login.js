const SUBMIT   = $('#submit');

var email    = null;
var password = null;


function updateInfo() {
    email    = $('#username').val();
    password = $('#password').val();
}

function checkDisablingButton() {
    if (!email || !password)
        SUBMIT.attr('disabled', 'disabled');
    else
        SUBMIT.removeAttr('disabled');
}

$('#loginForm').change(() => {
    updateInfo();
    checkDisablingButton();
}); 



function loginUser() {
    updateInfo();
    console.log((email, password));
    
    AUTH.signInWithEmailAndPassword(email, password)
        .then(response => {
            localStorage.setItem('TOKEN', JSON.stringify(response))
            location.assign('index.html');
            window.alert('Welcome!');
        })
        .catch(error => alert('FAILED: ' + error));
}

SUBMIT.click(loginUser);